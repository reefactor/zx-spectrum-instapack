
 This patch will translate the Russian ZX Spectrum emulator 3.05 to English.
 It uses the translation done by Random and adds a few things translated
 by me (I relied on my memory, and I haven't spoken Russian for 8 years,
 so beware!), so that the menu is now all-English. I also included a Russian
 font driver, in case you want to have a look at the original doc file
 or the error messages, etc.

 The emulator can be found here:
 ftp://ftp.void.jump.org/pub/sinclair/emulators/pc/dos/russian/spec305.zip
 The old patch by Random and someone else is on Void FTP, too:
 ftp://ftp.void.jump.org/pub/sinclair/emulators/pc/dos/russian/spec305.patch.zip
 but it doesn't translate the whole menu in v3.05 to English. My patch does.

 This will patch the file SPECTRUM.EXE, *without* making a backup.

 You use this patch at your own risk. I am not and will not be responsible for
 anything that may happen when you use it.


 By Jerry King / Cracow, Poland.

