#pragma once

int find1dlg(unsigned start);
int find2dlg(unsigned start);

void mon_emul();
void mon_setup_dlg();
void mon_scr0();
void mon_scr1();
void mon_scray();
void mon_exitsub();
void editbank();
void editextbank();
void mon_dump();
void mon_nxt();
void mon_prv();
void mon_tool();
void mon_watchdialog();
void mon_scrshot();
void mon_switch_cpu();
void mon_switch_dump();
