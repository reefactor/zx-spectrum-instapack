#pragma once

extern unsigned addr;
extern unsigned end;

void mon_save();
void mon_load();
void mon_fill();
