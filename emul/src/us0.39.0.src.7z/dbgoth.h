#pragma once

void mon_gsdialog();
void mon_setwatch();
void mon_switchay();

void __cdecl BankNames(int i, char *Name);
void showwatch();
void showstack();
void show_ay();
void showbanks();
void showports();
void showdos();
void show_time();
