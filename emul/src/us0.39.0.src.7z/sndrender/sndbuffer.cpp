#include "sndbuffer.h"

#ifdef SND_EXTERNAL_BUFFER
unsigned sndbuf[SNDBUFSIZE];
#endif
