#pragma once

void init_all(int argc, char **argv);
void __declspec(noreturn) exit();
