#pragma once

void init_bpx();
void done_bpx();

void mon_bpdialog();
unsigned calc(const Z80 *cpu, uintptr_t *script);
