#pragma once
void rend_atm6(unsigned char *dst, unsigned pitch, unsigned y, int Offset);
