
u8 xm(unsigned addr);
unsigned char rm(unsigned addr);
void wm(unsigned addr, unsigned char val);
void z80loop();
