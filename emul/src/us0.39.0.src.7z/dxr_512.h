#pragma once

void rend_512(unsigned char *dst, unsigned pitch);
