#pragma once
extern STEPFUNC const iy_opcode[];
