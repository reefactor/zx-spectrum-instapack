#pragma once
extern STEPFUNC const ext_opcode[];
