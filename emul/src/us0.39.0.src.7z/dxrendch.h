#pragma once

void __fastcall render_ch_ov(unsigned char *dst, unsigned pitch);
void __fastcall render_ch_hw(unsigned char *dst, unsigned pitch);
void __fastcall render_c16bl(unsigned char *dst, unsigned pitch);
void __fastcall render_c16b(unsigned char *dst, unsigned pitch);
void __fastcall render_c4x32b(unsigned char *dst, unsigned pitch);
