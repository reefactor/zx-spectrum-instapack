#pragma once
extern unsigned char fontatm2[2048];
extern const unsigned char fontatm2_default[2048];
